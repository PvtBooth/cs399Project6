Currently selecting a weekend in the calendar selector will not work. Please
do not select weekends.
