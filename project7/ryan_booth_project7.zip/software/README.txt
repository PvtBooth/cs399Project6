The game used to test is provided: "GAM150_Project.exe"
If run, it will output logs to the Logs folder.
Log.c, Log.h, Engine.c are provided to show how the logger was integrated.
Not all files are included that were used to log (too many).
Warning: the sound is very loud.
